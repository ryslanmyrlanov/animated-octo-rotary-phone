#include <iostream>
using namespace std;
int main(void){
    // Your code here!
    int a;
    int m3;
    int m5;
    int m35;
    
    for(a=0; a<=100; a++) {
        if(a%3==0) {
            if(a%5==0) {
                cout << "fizzbuzz" << endl;
            } else {
                cout << "fizz" << endl;   
            }
        } else {
            if(a%5==0) {
                cout << "buzz" << endl;
            } else {
                cout << a << endl;
            }
        }
    }
}
